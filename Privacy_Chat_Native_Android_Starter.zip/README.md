# Privacy Chat Native Android Starter

This is a **demo UI starter**, not a functional private messenger. It has login, lock and chat preview screens only. No real authentication, PIN protection, messages, photo uploads, end-to-end encryption or Supabase integration yet.

## GitHub Actions
The `.github/workflows/main.yml` workflow builds a debug APK using Gradle 8.9 and Android Gradle Plugin 8.7.3. Upload the **contents** of this project into the repository root, retaining directories, then run Actions -> Privacy Chat Android APK -> Run workflow. Download the `Privacy-Chat-Demo-APK` artifact and unzip to get `app-debug.apk`.

## Security roadmap
Integrate Supabase Auth, verified friend requests, row-level security policies, secure media access, real chat lock backed by Android Keystore and encrypted local storage, and conduct security tests before handling private messages. Do not commit Supabase service-role keys or user passwords to GitHub.
